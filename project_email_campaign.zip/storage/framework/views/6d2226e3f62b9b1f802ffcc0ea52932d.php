<?php $__env->startSection('title', $list->name); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="mb-0"><?php echo e(ucwords($list->name)); ?></h2>
    <div class="d-flex align-items-center gap-2">
        <a href="<?php echo e(route('lists.index')); ?>" class="btn btn-outline-secondary">
            <i class="bx bx-arrow-back"></i>
        </a>
        <a href="<?php echo e(route('lists.edit', $list)); ?>" class="btn btn-warning">Edit</a>
        <a href="<?php echo e(route('subscribers.export', $list)); ?>" class="btn btn-info">
            <i class="bx bx-export"></i> Export
        </a>
    </div>
</div>

<div class="row mb-4">
    <div class="col-md-3">
        <div class="card stat-card">
            <h3><?php echo e($subscriberCount); ?></h3>
            <p>Total Subscribers</p>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h5 class="mb-0">Subscribers in this List</h5>
    </div>
    <div class="table-responsive">
        <table class="table table-hover mb-0">
            <thead>
                <tr>
                    <th>Email</th>
                    <th>Name</th>
                    <th>Status</th>
                    <th>Subscribed</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $subscribers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscriber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($subscriber->email); ?></td>
                        <td><?php echo e(ucwords($subscriber->name ?? '-')); ?></td>
                        <td>
                            <span class="badge bg-<?php echo e($subscriber->status === 'active' ? 'success' : 'warning'); ?>">
                                <?php echo e(ucfirst($subscriber->status)); ?>

                            </span>
                        </td>
                        <td><?php echo e($subscriber->subscribed_at->format('M d, Y')); ?></td>
                        <td>
                            <a href="<?php echo e(route('subscribers.show', $subscriber)); ?>" class="btn btn-sm btn-outline-primary">
                                <i class="bx bx-show"></i>
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="text-center text-muted py-4">
                            No subscribers in this list
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php echo e($subscribers->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\email-campaign\resources\views/lists/show.blade.php ENDPATH**/ ?>