<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Email Campaign - <?php echo $__env->yieldContent('title'); ?></title>
    <link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">

    <!-- Scripts -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <style>
        :root { --sidebar-width: 260px; --bg-dark: #1a1c23; --bg-light: #f8f9fa; }
        body { background-color: var(--bg-light); font-family: 'Nunito', sans-serif; overflow-x: hidden; }
        
        /* Sidebar Styling */
        .sidebar { width: var(--sidebar-width); background: var(--bg-dark); height: 100vh; position: fixed; color: #fff; padding-top: 20px; transition: all 0.3s; z-index: 1000; }
        .sidebar .nav-link { color: #a0aec0; padding: 12px 25px; display: flex; align-items: center; gap: 10px; transition: 0.3s; }
        .sidebar .nav-link:hover, .sidebar .nav-link.active { color: #fff; background: rgba(255,255,255,0.05); border-left: 4px solid #3182ce; }
        .sidebar .nav-link i { font-size: 1.2rem; }
        .sidebar-heading { font-size: 0.75rem; text-transform: uppercase; letter-spacing: 0.05em; color: #718096; padding: 20px 25px 10px; }

        /* Main Content */
        .main-content { margin-left: var(--sidebar-width); min-height: 100vh; transition: all 0.3s; }
        .header { background: #fff; padding: 15px 30px; display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #e2e8f0; }
        
        /* Stats Cards */
        .stat-card { border: none; border-radius: 12px; transition: transform 0.2s; background: #fff; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1); }
        .stat-card:hover { transform: translateY(-5px); }
        .stat-icon { width: 48px; height: 48px; border-radius: 10px; display: flex; align-items: center; justify-content: center; font-size: 1.5rem; }
    </style>
</head>
<body>
    <?php if(auth()->guard()->check()): ?>
    <div class="sidebar">
        <div class="px-4 mb-4">
            <h4 class="text-white fw-bold"><i class="bx bxs-envelope text-info"></i> MailPulse</h4>
            <small class="text">Campaign Manager</small>
        </div>
        <a href="<?php echo e(route('dashboard')); ?>" class="nav-link <?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>">
            <i class='bx bxs-dashboard'></i> Dashboard
        </a>
        <a href="<?php echo e(route('campaigns.index')); ?>" class="nav-link <?php echo e(request()->is('campaigns*') ? 'active' : ''); ?>">
            <i class='bx bx-paper-plane'></i> Campaigns
        </a>
        <a href="<?php echo e(route('templates.index')); ?>" class="nav-link <?php echo e(request()->is('templates*') ? 'active' : ''); ?>">
            <i class='bx bx-layout'></i> Templates
        </a>
        <a href="<?php echo e(route('subscribers.index')); ?>" class="nav-link">
            <i class='bx bx-group'></i> Subscribers
        </a>
        <a href="<?php echo e(route('lists.index')); ?>" class="nav-link">
            <i class='bx bx-list-ul'></i> Lists
        </a>
        <a href="<?php echo e(route('settings.smtp.index')); ?>" class="nav-link">
            <i class='bx bx-cog'></i> SMTP Settings
        </a>
    </div>
    <?php endif; ?>

    <div class="<?php echo e(Auth::check() ? 'main-content' : ''); ?>">
        <?php if(auth()->guard()->check()): ?>
        <header class="header">
            <button class="btn border-0 d-md-none"><i class="bx bx-menu"></i></button>
            <div class="d-flex align-items-center gap-3 ms-auto">
                <span class="text-muted"><?php echo e(Auth::user()->name); ?></span>
                <form action="<?php echo e(route('logout')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-sm btn-outline-danger">Logout</button>
                </form>
            </div>
        </header>
        <?php endif; ?>

        <div class="p-4">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js" defer></script>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <script>
        $(document).ready(function () {
            $('#lists').select2({
                placeholder: "Select subscriber lists",
                allowClear: true,
                width: '100%'
            });
        });

        <?php if(session('success')): ?>
            toastr.success("<?php echo e(session('success')); ?>");
        <?php endif; ?>

        <?php if(session('error')): ?>
            toastr.error("<?php echo e(session('error')); ?>");
        <?php endif; ?>

        <?php if(session('warning')): ?>
            toastr.warning("<?php echo e(session('warning')); ?>");
        <?php endif; ?>

        <?php if(session('info')): ?>
            toastr.info("<?php echo e(session('info')); ?>");
        <?php endif; ?>

        toastr.options = {
            "closeButton": true,
            "progressBar": true,
            "positionClass": "toast-top-right",
            "timeOut": "3000",
        };
    </script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\email_campaign\resources\views/layouts/app.blade.php ENDPATH**/ ?>