

<?php $__env->startSection('title', 'Subscribers'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>Subscribers</h2>
    <div>
        <a href="<?php echo e(route('subscribers.create')); ?>" class="btn btn-primary">
            <i class="bx bx-user-plus"></i> Add Subscriber
        </a>
        <a href="javascript:void(0)"
            class="btn btn-info"
            data-bs-toggle="modal"
            data-bs-target="#importCsvModal">
            <i class="bx bx-import"></i> Import CSV
        </a>
    </div>
</div>

<div class="card">
    <div class="table-responsive">
        <table class="table table-hover mb-0">
            <thead>
                <tr>
                    <th>Email</th>
                    <th>Name</th>
                    <th>Status</th>
                    <th>Lists</th>
                    <th>Subscribed</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $subscribers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscriber): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($subscriber->email); ?></td>
                        <td><?php echo e(ucwords($subscriber->name ?? '-')); ?></td>
                        <td>
                            <?php if($subscriber->status === 'active'): ?>
                                <span class="badge bg-success">Active</span>
                            <?php elseif($subscriber->status === 'unsubscribed'): ?>
                                <span class="badge bg-warning">Unsubscribed</span>
                            <?php else: ?>
                                <span class="badge bg-secondary"><?php echo e(ucfirst($subscriber->status)); ?></span>
                            <?php endif; ?>
                        </td>
                        <td>
                           <?php echo e($subscriber->lists->pluck('name')->map(fn ($name) => ucwords($name))->join(', ') ?: '-'); ?>

                        </td>
                        <td><?php echo e($subscriber->subscribed_at->format('M d, Y')); ?></td>
                        <td>
                            <div class="btn-group" role="group">
                                <a href="<?php echo e(route('subscribers.show', $subscriber)); ?>" class="btn btn-outline-primary" title="View">
                                    <i class="bx bx-show"></i>
                                </a>
                                <a href="<?php echo e(route('subscribers.edit', $subscriber)); ?>" class="btn btn-outline-warning" title="Edit">
                                    <i class="bx bx-edit"></i>
                                </a>
                                <form action="<?php echo e(route('subscribers.destroy', $subscriber)); ?>"
                                    method="POST"
                                    class="d-inline-flex m-0 delete-form">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>

                                    <button type="button"
                                            class="btn btn-outline-danger btn-delete"
                                            style="border-top-left-radius: 0; border-bottom-left-radius: 0;"
                                            title="Delete">
                                        <i class="bx bx-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="text-center text-muted py-4">
                            No subscribers found. <a href="<?php echo e(route('subscribers.create')); ?>">Add one now</a>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="modal fade" id="importCsvModal" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-md modal-dialog-centered">
            <div class="modal-content">

                <form action="<?php echo e(route('subscribers.importStore')); ?>"
                    method="POST"
                    enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>

                    <div class="modal-header">
                        <h5 class="modal-title">
                            <i class="bx bx-import"></i> Import Subscribers (CSV)
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>

                    <div class="modal-body">

                        <!-- CSV File -->
                        <div class="mb-3">
                            <label class="form-label">CSV File <span class="text-danger">*</span></label>
                            <input type="file"
                                name="file"
                                class="form-control"
                                accept=".csv"
                                required>
                            <small class="text-muted">
                                Allowed format: email, name
                            </small>
                        </div>

                        <!-- Subscriber List -->
                        <div class="mb-3">
                            <label class="form-label">Add to List (optional)</label>
                            <select name="list_id" class="form-select">
                                <option value="">-- Select List --</option>
                                <?php $__currentLoopData = $lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($list->id); ?>">
                                        <?php echo e(ucwords($list->name)); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                    </div>

                    <div class="modal-footer">
                        <button type="button"
                                class="btn btn-secondary"
                                data-bs-dismiss="modal">
                            Cancel
                        </button>
                        <button type="submit" class="btn btn-primary">
                            <i class="bx bx-upload"></i> Import
                        </button>
                    </div>

                </form>

            </div>
        </div>
    </div>
</div>

<?php echo e($subscribers->links()); ?>

<?php $__env->stopSection(); ?>

<script>
    document.addEventListener('DOMContentLoaded', function () {

        document.querySelectorAll('.btn-delete').forEach(button => {
            button.addEventListener('click', function () {

                const form = this.closest('.delete-form');

                Swal.fire({
                    title: 'Are you sure?',
                    text: "This subscriber will be permanently deleted!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#dc3545',
                    cancelButtonColor: '#6c757d',
                    confirmButtonText: 'Yes, delete it!',
                    cancelButtonText: 'Cancel'
                }).then((result) => {
                    if (result.isConfirmed) {
                        form.submit();
                    }
                });

            });
        });

    });
</script>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\email_campaign\resources\views/subscribers/index.blade.php ENDPATH**/ ?>