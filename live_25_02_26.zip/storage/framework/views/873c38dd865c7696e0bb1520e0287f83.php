

<?php $__env->startSection('title', 'Campaigns'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>Campaigns</h2>
    <a href="<?php echo e(route('campaigns.create')); ?>" class="btn btn-primary">
        <i class="bx bx-plus"></i> New Campaign
    </a>
</div>

<div class="card">
    <div class="table-responsive">
        <table class="table table-hover mb-0">
            <thead>
                <tr>
                    <th>Campaign Name</th>
                    <th>Subject</th>
                    <th>List</th>
                    <th>Status</th>
                    <th>Recipients</th>
                    <th>Sent</th>
                    <th>Open Rate</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $campaigns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $campaign): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <a href="<?php echo e(route('campaigns.show', $campaign)); ?>" class="text-decoration-none">
                                <?php echo e(ucwords($campaign->name)); ?>

                            </a>
                        </td>
                        <td><?php echo e(Str::limit(ucwords($campaign->subject), 40)); ?></td>
                        <td><?php echo e(ucwords($campaign->list->name)); ?></td>
                        <td>
                            <?php if($campaign->isDraft()): ?>
                                <span class="badge bg-warning">Draft</span>
                            <?php elseif($campaign->isScheduled()): ?>
                                <span class="badge bg-info">Scheduled</span>
                            <?php elseif($campaign->isSending()): ?>
                                <span class="badge bg-primary">Sending</span>
                            <?php else: ?>
                                <span class="badge bg-success">Sent</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($campaign->total_subscribers); ?></td>
                        <td><?php echo e($campaign->sent_count); ?></td>
                        <td><?php echo e($campaign->getOpenRate()); ?>%</td>
                        <td>
                            <div class="btn-group" role="group">
                                <a href="<?php echo e(route('campaigns.show', $campaign)); ?>" class="btn btn-outline-primary" title="View">
                                    <i class="bx bx-show"></i>
                                </a>
                                <?php if($campaign->isDraft()): ?>
                                    <a href="<?php echo e(route('campaigns.edit', $campaign)); ?>" class="btn btn-outline-warning" title="Edit">
                                        <i class="bx bx-edit"></i>
                                    </a>
                                    <form action="<?php echo e(route('campaigns.destroy', $campaign)); ?>"
                                        method="POST"
                                        class="d-inline-flex m-0 delete-form">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>

                                        <button type="button"
                                                class="btn btn-outline-danger btn-delete"
                                                 style="border-top-left-radius: 0; border-bottom-left-radius: 0;"
                                                title="Delete">
                                            <i class="bx bx-trash"></i>
                                        </button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="8" class="text-center text-muted py-4">
                            No campaigns found. <a href="<?php echo e(route('campaigns.create')); ?>">Create one now</a>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php echo e($campaigns->links()); ?>

<?php $__env->stopSection(); ?>

<script>
    document.addEventListener('DOMContentLoaded', function () {

        document.querySelectorAll('.btn-delete').forEach(button => {
            button.addEventListener('click', function () {

                const form = this.closest('.delete-form');

                Swal.fire({
                    title: 'Are you sure?',
                    text: "This campaign will be permanently deleted!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#dc3545',
                    cancelButtonColor: '#6c757d',
                    confirmButtonText: 'Yes, delete it!',
                    cancelButtonText: 'Cancel'
                }).then((result) => {
                    if (result.isConfirmed) {
                        form.submit();
                    }
                });

            });
        });

    });
</script>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\email_campaign\resources\views/campaigns/index.blade.php ENDPATH**/ ?>