

<?php $__env->startSection('title', 'Subscriber Lists'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>Subscriber Lists</h2>
    <a href="<?php echo e(route('lists.create')); ?>" class="btn btn-primary">
        <i class="bx bx-plus"></i> New List
    </a>
</div>

<div class="card">
    <div class="table-responsive">
        <table class="table table-hover mb-0">
            <thead>
                <tr>
                    <th>List Name</th>
                    <th>Description</th>
                    <th>Subscribers</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <a href="<?php echo e(route('lists.show', $list)); ?>" class="text-decoration-none">
                                <?php echo e(ucwords($list->name)); ?>

                            </a>
                        </td>
                        <td><?php echo e(Str::limit(ucwords($list->description), 50)); ?></td>
                        <td>
                            <span class="badge bg-info"><?php echo e($list->subscribers_count ?? 0); ?></span>
                        </td>
                        <td>
                            <form action="<?php echo e(route('subscriber-lists.toggle-status', $list)); ?>"
                                method="POST"
                                class="d-inline">
                                <?php echo csrf_field(); ?>
                                <div class="form-check form-switch">
                                    <input class="form-check-input"
                                        type="checkbox"
                                        role="switch"
                                        id="toggle-<?php echo e($list->id); ?>"
                                        <?php echo e($list->is_active ? 'checked' : ''); ?>

                                        onchange="this.form.submit()">
                                </div>
                            </form>
                        </td>
                        <td>
                            <div class="btn-group" role="group">
                                <a href="<?php echo e(route('lists.show', $list)); ?>" class="btn btn-outline-primary" title="View">
                                    <i class="bx bx-show"></i>
                                </a>
                                <a href="<?php echo e(route('lists.edit', $list)); ?>" class="btn btn-outline-warning" title="Edit">
                                    <i class="bx bx-edit"></i>
                                </a>
                                <a href="<?php echo e(route('subscribers.export', $list)); ?>" class="btn btn-outline-info" title="Export">
                                    <i class="bx bx-export"></i>
                                </a>
                                <form action="<?php echo e(route('lists.destroy', $list)); ?>"
                                    method="POST"
                                    class="d-inline-flex m-0 delete-form">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>

                                    <button type="button"
                                            class="btn btn-outline-danger btn-delete"
                                            style="border-top-left-radius: 0; border-bottom-left-radius: 0;"
                                            title="Delete">
                                        <i class="bx bx-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="text-center text-muted py-4">
                            No lists found. <a href="<?php echo e(route('lists.create')); ?>">Create one now</a>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php echo e($lists->links()); ?>

<?php $__env->stopSection(); ?>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        document.querySelectorAll('.btn-delete').forEach(button => {
            button.addEventListener('click', function () {

                const form = this.closest('.delete-form');

                Swal.fire({
                    title: 'Are you sure?',
                    text: "This list will be permanently deleted!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#dc3545',
                    cancelButtonColor: '#6c757d',
                    confirmButtonText: 'Yes, delete it!',
                    cancelButtonText: 'Cancel'
                }).then((result) => {
                    if (result.isConfirmed) {
                        form.submit();
                    }
                });

            });
        });

    });

    document.addEventListener('DOMContentLoaded', function () {

        document.querySelectorAll('.toggle-status').forEach(toggle => {

            toggle.addEventListener('change', function () {

                let checkbox = this;
                let url = this.dataset.url;
                let badge = this.closest('td').querySelector('.status-badge');

                fetch(url, {
                    method: 'POST',
                    headers: {
                        'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                        'Accept': 'application/json'
                    }
                })
                .then(res => res.json())
                .then(data => {

                    if (data.success) {
                        badge.textContent = data.status ? 'Active' : 'Inactive';
                        badge.classList.toggle('bg-success', data.status);
                        badge.classList.toggle('bg-secondary', !data.status);
                    } else {
                        checkbox.checked = !checkbox.checked;
                    }

                })
                .catch(() => {
                    checkbox.checked = !checkbox.checked;
                });

            });

        });

    });
</script>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\email_campaign\resources\views/lists/index.blade.php ENDPATH**/ ?>