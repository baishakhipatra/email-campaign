

<?php $__env->startSection('title', 'Email Templates'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>Email Templates</h2>
    <a href="<?php echo e(route('templates.create')); ?>" class="btn btn-primary">
        <i class="bx bx-plus"></i> New Template
    </a>
</div>

<div class="card">
    <div class="table-responsive">
        <table class="table table-hover mb-0">
            <thead>
                <tr>
                    <th>Template Name</th>
                    <th>Description</th>
                    <th>Created By</th>
                    <th>Status</th>
                    <th>Created</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $templates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $template): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>
                            <a href="<?php echo e(route('templates.show', $template)); ?>" class="text-decoration-none">
                                <?php echo e(ucwords($template->name)); ?>

                            </a>
                        </td>
                        <td><?php echo e(Str::limit(ucwords($template->description), 50)); ?></td>
                        <td><?php echo e($template->creator->name); ?></td>
                        <td>
                            <form action="<?php echo e(route('templates.toggle-status', $template)); ?>"
                                method="POST"
                                class="d-inline">
                                <?php echo csrf_field(); ?>
                                <div class="form-check form-switch">
                                    <input class="form-check-input"
                                        type="checkbox"
                                        role="switch"
                                        id="toggle-<?php echo e($template->id); ?>"
                                        <?php echo e($template->is_active ? 'checked' : ''); ?>

                                        onchange="this.form.submit()">
                                </div>
                            </form>
                        </td>
                        <td><?php echo e($template->created_at->format('M d, Y')); ?></td>
                        <td>
                            <div class="btn-group" role="group">
                                <a href="<?php echo e(route('templates.show', $template)); ?>" class="btn btn-outline-primary" title="View">
                                    <i class="bx bx-show"></i>
                                </a>
                                <a href="<?php echo e(route('templates.edit', $template)); ?>" class="btn btn-outline-warning" title="Edit">
                                    <i class="bx bx-edit"></i>
                                </a>
                                <form action="<?php echo e(route('templates.destroy', $template)); ?>"
                                    method="POST"
                                    class="d-inline-flex m-0 delete-form">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>

                                    <button type="button"
                                            class="btn btn-outline-danger btn-delete"
                                            style="border-top-left-radius: 0; border-bottom-left-radius: 0;"
                                            title="Delete">
                                        <i class="bx bx-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="text-center text-muted py-4">
                            No templates found. <a href="<?php echo e(route('templates.create')); ?>">Create one now</a>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php echo e($templates->links()); ?>

<?php $__env->stopSection(); ?>

<script>
    document.addEventListener('DOMContentLoaded', function () {

        document.querySelectorAll('.btn-delete').forEach(button => {
            button.addEventListener('click', function () {

                const form = this.closest('.delete-form');

                Swal.fire({
                    title: 'Are you sure?',
                    text: "This template will be permanently deleted!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#dc3545',
                    cancelButtonColor: '#6c757d',
                    confirmButtonText: 'Yes, delete it!',
                    cancelButtonText: 'Cancel'
                }).then((result) => {
                    if (result.isConfirmed) {
                        form.submit();
                    }
                });

            });
        });

    });
</script>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\email_campaign\resources\views/templates/index.blade.php ENDPATH**/ ?>