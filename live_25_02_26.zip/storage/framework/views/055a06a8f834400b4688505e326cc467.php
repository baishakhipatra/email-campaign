

<?php $__env->startSection('title', $subscriber->email); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-4">
    <div class="d-flex align-items-center gap-2">

        <h5 class="mb-0 fw-semibold"><?php echo e($subscriber->email); ?></h5>
    </div>
    <div class="d-flex gap-2">
        <a href="<?php echo e(route('subscribers.index')); ?>" class="btn btn-outline-secondary btn-sm">
            <i class="bx bx-arrow-back"></i>
        </a>
        <a href="<?php echo e(route('subscribers.edit', $subscriber)); ?>" class="btn btn-warning btn-sm">
            <i class="bx bx-edit"></i> Edit
        </a>
    </div>
</div>

<div class="row">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Subscriber Info</h5>
            </div>
            <div class="card-body">
                <table class="table table-sm">
                    <tr>
                        <td><strong>Email:</strong></td>
                        <td><?php echo e($subscriber->email); ?></td>
                    </tr>
                    <tr>
                        <td><strong>Name:</strong></td>
                        <td><?php echo e(ucwords($subscriber->name ?? '-')); ?></td>
                    </tr>
                    <tr>
                        <td><strong>Status:</strong></td>
                        <td>
                            <span class="badge bg-<?php echo e($subscriber->status === 'active' ? 'success' : 'warning'); ?>">
                                <?php echo e(ucfirst($subscriber->status)); ?>

                            </span>
                        </td>
                    </tr>
                    <tr>
                        <td><strong>Subscribed:</strong></td>
                        <td><?php echo e($subscriber->subscribed_at->format('M d, Y H:i')); ?></td>
                    </tr>
                </table>
            </div>
        </div>
    </div>

    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Lists</h5>
            </div>
            <div class="card-body">
                <?php $__empty_1 = true; $__currentLoopData = $subscriber->lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <span class="badge bg-primary"><?php echo e(ucwords($list->name)); ?></span>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-muted">Not assigned to any list</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div class="row mt-3">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Campaign Activity</h5>
            </div>
            <div class="card-body">
                <p class="text-muted">Emails Sent: <?php echo e($subscriber->emailLogs()->count()); ?></p>
                <p class="text-muted">Emails Opened: <?php echo e($subscriber->openLogs()->count()); ?></p>
                <p class="text-muted">Links Clicked: <?php echo e($subscriber->clickLogs()->count()); ?></p>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\email_campaign\resources\views/subscribers/show.blade.php ENDPATH**/ ?>