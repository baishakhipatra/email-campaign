@extends('layouts.app')

@section('content')

<form method="POST" action="{{ route('password.update') }}">
    @csrf
    <label>Email Address</label>
    <input type="email" name="email" required value="{{ old('email') }}">
    
    <label>New Password</label>
    <input type="password" name="password" required>
    
    <label>Confirm New Password</label>
    <input type="password" name="password_confirmation" required>
    
    <button type="submit">Update Password</button>
</form>

@if ($errors->any())
    <div class="alert alert-danger">
        {{ $errors->first() }}
    </div>
@endif

@endsection