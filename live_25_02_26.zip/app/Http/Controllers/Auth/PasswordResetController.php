<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User; 
use Illuminate\Support\Facades\Hash;

class PasswordResetController extends Controller
{
    public function showForm(){
        return view('auth.passwords.password-reset');
    }

    public function reset(Request $request){
        $request->validate([
            'email' => 'required|email|exists:users,email',
            'password' => 'required|min:6|confirmed',
        ], [
            'email.exists' => 'No account found with this email address.',
        ]);

        $user = User::where('email', $request->email)->first();

        if ($user) {
            $user->update([
                'password' => Hash::make($request->password)
            ]);

            return redirect()->route('login')->with('success', 'Password updated successfully! You can now login.');
        }

        return back()->withErrors(['email' => 'Unable to update password.']);
    }
}
