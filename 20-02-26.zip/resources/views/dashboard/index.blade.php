@extends('layouts.app')

@section('title', 'Dashboard')

@section('content')
<h2 class="mb-4">Dashboard</h2>

<!-- Statistics Row -->
<div class="row mb-4">
    <div class="col-md-3">
        <div class="card stat-card">
            <h3>{{ $totalSubscribers }}</h3>
            <p>Total Subscribers</p>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card stat-card">
            <h3>{{ $totalCampaigns }}</h3>
            <p>Total Campaigns</p>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card stat-card">
            <h3>{{ $totalSent }}</h3>
            <p>Emails Sent</p>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card stat-card">
            <h3>{{ $averageOpenRate }}%</h3>
            <p>Avg Open Rate</p>
        </div>
    </div>
</div>

<!-- Metrics Row -->
<div class="row mb-4">
    <div class="col-md-6">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Average Click Rate</h5>
                <div class="display-4" style="color: #667eea;">{{ $averageClickRate }}%</div>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Quick Actions</h5>
                <div class="btn-group-vertical w-100">
                    <a href="{{ route('campaigns.create') }}" class="btn btn-primary btn-sm mb-2">
                        <i class="bx bx-plus"></i> New Campaign
                    </a>
                    <a href="{{ route('subscribers.create') }}" class="btn btn-primary btn-sm mb-2">
                        <i class="bx bx-user-plus"></i> Add Subscriber
                    </a>
                    <a href="{{ route('templates.create') }}" class="btn btn-primary btn-sm">
                        <i class="bx bx-file-blank"></i> New Template
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Recent Campaigns -->
<div class="card">
    <div class="card-header">
        <h5 class="mb-0">Recent Campaigns</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Campaign Name</th>
                        <th>Status</th>
                        <th>Recipients</th>
                        <th>Sent</th>
                        <th>Open Rate</th>
                        <th>Click Rate</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse ($recentCampaigns as $campaign)
                        <tr>
                            <td>
                                <a href="{{ route('campaigns.show', $campaign) }}">
                                    {{ $campaign->name }}
                                </a>
                            </td>
                            <td>
                                <span class="badge bg-info">{{ ucfirst($campaign->status) }}</span>
                            </td>
                            <td>{{ $campaign->total_subscribers }}</td>
                            <td>{{ $campaign->sent_count }}</td>
                            <td>{{ $campaign->getOpenRate() }}%</td>
                            <td>{{ $campaign->getClickRate() }}%</td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="6" class="text-center text-muted">No campaigns yet</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>

@push('scripts')
<script>
    // Chart for campaign performance
    if (document.getElementById('performanceChart')) {
        const chartData = {!! json_encode($chartData) !!};
        const ctx = document.getElementById('performanceChart').getContext('2d');
        
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: chartData.map(c => c.name),
                datasets: [
                    {
                        label: 'Opens',
                        data: chartData.map(c => c.opens),
                        backgroundColor: '#667eea'
                    },
                    {
                        label: 'Clicks',
                        data: chartData.map(c => c.clicks),
                        backgroundColor: '#764ba2'
                    }
                ]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    title: {
                        display: true,
                        text: 'Campaign Performance'
                    }
                }
            }
        });
    }
</script>
@endpush
@endsection
