@extends('layouts.app')

@section('title', 'Subscribers')

@section('content')
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2>Subscribers</h2>
    <div>
        <a href="{{ route('subscribers.create') }}" class="btn btn-primary">
            <i class="bx bx-user-plus"></i> Add Subscriber
        </a>
        <a href="{{ route('subscribers.import') }}" class="btn btn-info">
            <i class="bx bx-import"></i> Import CSV
        </a>
    </div>
</div>

<div class="card">
    <div class="table-responsive">
        <table class="table table-hover mb-0">
            <thead>
                <tr>
                    <th>Email</th>
                    <th>Name</th>
                    <th>Status</th>
                    <th>Lists</th>
                    <th>Subscribed</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                @forelse ($subscribers as $subscriber)
                    <tr>
                        <td>{{ $subscriber->email }}</td>
                        <td>{{ $subscriber->name ?? '-' }}</td>
                        <td>
                            @if($subscriber->status === 'active')
                                <span class="badge bg-success">Active</span>
                            @elseif($subscriber->status === 'unsubscribed')
                                <span class="badge bg-warning">Unsubscribed</span>
                            @else
                                <span class="badge bg-secondary">{{ ucfirst($subscriber->status) }}</span>
                            @endif
                        </td>
                        <td>
                            {{ $subscriber->lists->pluck('name')->join(', ') ?: '-' }}
                        </td>
                        <td>{{ $subscriber->subscribed_at->format('M d, Y') }}</td>
                        <td>
                            <div class="btn-group" role="group">
                                <a href="{{ route('subscribers.show', $subscriber) }}" class="btn btn-sm btn-outline-primary" title="View">
                                    <i class="bx bx-show"></i>
                                </a>
                                <a href="{{ route('subscribers.edit', $subscriber) }}" class="btn btn-sm btn-outline-warning" title="Edit">
                                    <i class="bx bx-edit"></i>
                                </a>
                                <form action="{{ route('subscribers.destroy', $subscriber) }}" method="POST" style="display: inline;">
                                    @csrf @method('DELETE')
                                    <button type="submit" class="btn btn-sm btn-outline-danger" title="Delete" onclick="return confirm('Are you sure?')">
                                        <i class="bx bx-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="6" class="text-center text-muted py-4">
                            No subscribers found. <a href="{{ route('subscribers.create') }}">Add one now</a>
                        </td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>

{{ $subscribers->links() }}
@endsection
