

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<h2 class="mb-4">Dashboard</h2>

<!-- Statistics Row -->
<div class="row mb-4">
    <div class="col-md-3">
        <div class="card stat-card">
            <h3><?php echo e($totalSubscribers); ?></h3>
            <p>Total Subscribers</p>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card stat-card">
            <h3><?php echo e($totalCampaigns); ?></h3>
            <p>Total Campaigns</p>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card stat-card">
            <h3><?php echo e($totalSent); ?></h3>
            <p>Emails Sent</p>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card stat-card">
            <h3><?php echo e($averageOpenRate); ?>%</h3>
            <p>Avg Open Rate</p>
        </div>
    </div>
</div>

<!-- Metrics Row -->
<div class="row mb-4">
    <div class="col-md-6">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Average Click Rate</h5>
                <div class="display-4" style="color: #667eea;"><?php echo e($averageClickRate); ?>%</div>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title">Quick Actions</h5>
                <div class="btn-group-vertical w-100">
                    <a href="<?php echo e(route('campaigns.create')); ?>" class="btn btn-primary btn-sm mb-2">
                        <i class="bx bx-plus"></i> New Campaign
                    </a>
                    <a href="<?php echo e(route('subscribers.create')); ?>" class="btn btn-primary btn-sm mb-2">
                        <i class="bx bx-user-plus"></i> Add Subscriber
                    </a>
                    <a href="<?php echo e(route('templates.create')); ?>" class="btn btn-primary btn-sm">
                        <i class="bx bx-file-blank"></i> New Template
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Recent Campaigns -->
<div class="card">
    <div class="card-header">
        <h5 class="mb-0">Recent Campaigns</h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Campaign Name</th>
                        <th>Status</th>
                        <th>Recipients</th>
                        <th>Sent</th>
                        <th>Open Rate</th>
                        <th>Click Rate</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $recentCampaigns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $campaign): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td>
                                <a href="<?php echo e(route('campaigns.show', $campaign)); ?>">
                                    <?php echo e($campaign->name); ?>

                                </a>
                            </td>
                            <td>
                                <span class="badge bg-info"><?php echo e(ucfirst($campaign->status)); ?></span>
                            </td>
                            <td><?php echo e($campaign->total_subscribers); ?></td>
                            <td><?php echo e($campaign->sent_count); ?></td>
                            <td><?php echo e($campaign->getOpenRate()); ?>%</td>
                            <td><?php echo e($campaign->getClickRate()); ?>%</td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" class="text-center text-muted">No campaigns yet</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
    // Chart for campaign performance
    if (document.getElementById('performanceChart')) {
        const chartData = <?php echo json_encode($chartData); ?>;
        const ctx = document.getElementById('performanceChart').getContext('2d');
        
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: chartData.map(c => c.name),
                datasets: [
                    {
                        label: 'Opens',
                        data: chartData.map(c => c.opens),
                        backgroundColor: '#667eea'
                    },
                    {
                        label: 'Clicks',
                        data: chartData.map(c => c.clicks),
                        backgroundColor: '#764ba2'
                    }
                ]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    title: {
                        display: true,
                        text: 'Campaign Performance'
                    }
                }
            }
        });
    }
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\email_campaign\resources\views/dashboard/index.blade.php ENDPATH**/ ?>